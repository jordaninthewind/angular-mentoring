const presets = [["@babel/env",]];

module.exports = { presets };